# Wedding Photography Website + Admin Panel

Portfolio site in the style of namanverma.com/weddings: hero strip, "Real Love Stories" list,
story gallery pages with lightbox, About, Enquire form. Includes an admin panel to manage
stories (folders) and the photos inside each one. **No npm install needed** - only Node.js 16+.

## Run
    node server.js
    # or with your own password/port:
    ADMIN_PASSWORD=MySecret123 PORT=3000 node server.js

- Site:  http://localhost:3000
- Admin: http://localhost:3000/admin   (default password `admin123` - CHANGE IT)

## Admin features
- **Stories**: create / edit / delete / publish-unpublish, drag to reorder on the homepage
- **Photos** inside each story: multi-upload (drag & drop), drag to reorder, set cover, captions, delete
- **Site settings**: name, headline, intro, quote, about text + photo, email, Instagram
- **Enquiries**: messages from the contact form

## Files
    server.js            Node server: API, auth, uploads, static files (no dependencies)
    package.json
    .env.example         ADMIN_PASSWORD, PORT
    public/index.html    Home page            public/js/site.js
    public/story.html    Story gallery page   public/js/story.js
    public/admin.html    Admin panel          public/js/admin.js, public/css/admin.css
    public/css/site.css  Public styling       public/js/common.js (shared helpers)
    data/db.json         Auto-created. All text content lives here
    uploads/<storyId>/   Uploaded photos

## Going live
1. Host on any Node-capable host (VPS, Render, Railway, Fly.io...). Run `node server.js`.
2. Put it behind HTTPS (Nginx/Caddy or the host's built-in TLS) and set `ADMIN_PASSWORD`.
3. **Persist `data/` and `uploads/`** (use a persistent disk/volume) - they hold all your content.
4. Back up those two folders regularly.
5. Photos are stored as uploaded. Resize to ~2400px long edge / JPEG before uploading for fast loading.

## Customising
- Colours/fonts: top of `public/css/site.css` (`:root` variables, Google Fonts link in the HTML).
- Menu items: `<nav>` in `public/index.html` and `public/story.html`.
- Max upload per request is 200 MB (`MAX_UPLOAD` in server.js); the admin uploads 5 photos per request.
